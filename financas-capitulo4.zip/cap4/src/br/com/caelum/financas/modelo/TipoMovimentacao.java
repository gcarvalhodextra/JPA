package br.com.caelum.financas.modelo;

public enum TipoMovimentacao {

	ENTRADA, SAIDA;

}
